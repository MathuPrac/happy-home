import type { Request, Response } from 'express';
import type { ApiResponse } from '@restaurant/shared-types';
import type { UpdateOrderStatusDto } from '../dtos/update-order-status.dto';
import { OrderService } from '../services/order.service';
import { OrderStatus } from '@restaurant/shared-types';

export class OrdersController {
  constructor(private readonly orderService: OrderService) {}

  async createOrder(req: Request, res: Response): Promise<void> {
    const order = await this.orderService.createOrder(req.user!.sub, req.body);
    const response: ApiResponse = { success: true, data: order, message: 'Order created successfully' };
    res.status(201).json(response);
  }

  async getOrder(req: Request, res: Response): Promise<void> {
    const order = await this.orderService.getOrderById(req.params.id);
    res.json({ success: true, data: order });
  }

  async getMyOrders(req: Request, res: Response): Promise<void> {
    const query = req.query as { page: number; limit: number; status?: OrderStatus };
    const result = await this.orderService.getCustomerOrders(req.user!.sub, query);
    res.json({ success: true, ...result });
  }

  async getRestaurantOrders(req: Request, res: Response): Promise<void> {
    const query = req.query as { page: number; limit: number; status?: OrderStatus };
    const result = await this.orderService.getRestaurantOrders(req.params.restaurantId, query);
    res.json({ success: true, ...result });
  }

  async getRestaurantPendingOrders(req: Request, res: Response): Promise<void> {
    const orders = await this.orderService.getPendingOrders(req.params.restaurantId);
    res.json({ success: true, data: orders });
  }

  async getRiderActiveOrders(req: Request, res: Response): Promise<void> {
    const orders = await this.orderService.getActiveRiderOrders(req.user!.sub);
    res.json({ success: true, data: orders });
  }

  async updateOrderStatus(req: Request, res: Response): Promise<void> {
    const updatedOrder = await this.orderService.updateOrderStatus(
      req.params.orderId,
      req.body as UpdateOrderStatusDto,
      req.user!,
    );
    res.json({ success: true, data: updatedOrder });
  }
}
