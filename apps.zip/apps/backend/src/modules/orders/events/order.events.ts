import { OrderStatus } from '@restaurant/shared-types';

export const ORDER_EVENTS = {
  CREATED: 'order:created',
  STATUS_CHANGED: 'order:status:changed',
  RIDER_ASSIGNED: 'order:rider:assigned',
  CANCELLED: 'order:cancelled',
} as const;

export type OrderEventType = (typeof ORDER_EVENTS)[keyof typeof ORDER_EVENTS];

export interface OrderCreatedPayload {
  orderId: string;
  customerId: string;
  restaurantId: string;
  total: number;
  createdAt: Date;
}

export interface OrderStatusChangedPayload {
  orderId: string;
  restaurantId: string;
  customerId: string;
  previousStatus: OrderStatus;
  newStatus: OrderStatus;
  changedAt: Date;
}

export interface RiderAssignedPayload {
  orderId: string;
  riderId: string;
  restaurantId: string;
  customerId: string;
}
