import { Router } from 'express';
import { OrdersController } from './controllers/orders.controller';
import { OrderService } from './services/order.service';
import { OrderRepository } from './repositories/order.repository';
import { CacheService } from '@/infrastructure/cache/redis';
import {
	authenticate,
	authorize,
	requireCustomer,
	requireRider,
	requireRestaurantOwner,
	validate,
} from '@/core/middleware';
import { UserRole } from '@restaurant/shared-types';
import {
	createOrderSchema,
	updateOrderStatusSchema,
	getOrdersQuerySchema,
} from './validations/order.validators';

const router = Router();

// Dependency injection composition root
const orderRepo = new OrderRepository();
const cache = new CacheService();
const orderService = new OrderService(orderRepo, cache);
const controller = new OrdersController(orderService);

router.post(
	'/',
	authenticate,
	requireCustomer,
	validate(createOrderSchema),
	(req, res) => controller.createOrder(req, res),
);

router.get(
	'/my',
	authenticate,
	requireCustomer,
	validate(getOrdersQuerySchema),
	(req, res) => controller.getMyOrders(req, res),
);

router.get(
	'/restaurant/:restaurantId',
	authenticate,
	requireRestaurantOwner,
	validate(getOrdersQuerySchema),
	(req, res) => controller.getRestaurantOrders(req, res),
);

router.get(
	'/restaurant/:restaurantId/pending',
	authenticate,
	requireRestaurantOwner,
	(req, res) => controller.getRestaurantPendingOrders(req, res),
);

router.get(
	'/rider/me/active',
	authenticate,
	requireRider,
	(req, res) => controller.getRiderActiveOrders(req, res),
);

router.patch(
	'/:orderId/status',
	authenticate,
	authorize(UserRole.CUSTOMER, UserRole.RIDER, UserRole.RESTAURANT_OWNER, UserRole.ADMIN),
	validate(updateOrderStatusSchema),
	(req, res) => controller.updateOrderStatus(req, res),
);

router.get(
	'/:id',
	authenticate,
	authorize(UserRole.CUSTOMER, UserRole.RIDER, UserRole.RESTAURANT_OWNER, UserRole.ADMIN),
	(req, res) => controller.getOrder(req, res),
);

export const ordersRouter = router;
