import type { CreateOrderDto } from '../dtos/create-order.dto';
import type { PaginationQuery } from '@restaurant/shared-types';
import type { JwtAccessPayload } from '@/types';
import type { UpdateOrderStatusDto } from '../dtos/update-order-status.dto';
import { OrderStatus, UserRole } from '@restaurant/shared-types';
import { OrderRepository } from '../repositories/order.repository';
import { CacheService } from '../../../infrastructure/cache/redis/cache.service';
import { BadRequestError, ForbiddenError, NotFoundError } from '@/core/errors';
import { Logger } from '../../../shared/utils/logger';

const ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  [OrderStatus.PENDING]: [OrderStatus.CONFIRMED, OrderStatus.CANCELLED],
  [OrderStatus.CONFIRMED]: [OrderStatus.PREPARING, OrderStatus.CANCELLED],
  [OrderStatus.PREPARING]: [OrderStatus.READY_FOR_PICKUP],
  [OrderStatus.READY_FOR_PICKUP]: [OrderStatus.OUT_FOR_DELIVERY],
  [OrderStatus.OUT_FOR_DELIVERY]: [OrderStatus.DELIVERED],
  [OrderStatus.DELIVERED]: [],
  [OrderStatus.CANCELLED]: [],
};

const TRANSITION_PERMISSIONS: Partial<Record<OrderStatus, UserRole[]>> = {
  [OrderStatus.CONFIRMED]: [UserRole.RESTAURANT_OWNER, UserRole.ADMIN],
  [OrderStatus.PREPARING]: [UserRole.RESTAURANT_OWNER, UserRole.ADMIN],
  [OrderStatus.READY_FOR_PICKUP]: [UserRole.RESTAURANT_OWNER, UserRole.ADMIN],
  [OrderStatus.OUT_FOR_DELIVERY]: [UserRole.RIDER, UserRole.ADMIN],
  [OrderStatus.DELIVERED]: [UserRole.RIDER, UserRole.ADMIN],
  [OrderStatus.CANCELLED]: [UserRole.CUSTOMER, UserRole.RESTAURANT_OWNER, UserRole.ADMIN],
};

export class OrderService {
  private readonly logger = new Logger('OrderService');

  constructor(
    private readonly orderRepo: OrderRepository,
    private readonly cache: CacheService,
  ) {}

  async createOrder(customerId: string, dto: CreateOrderDto) {
    const subtotal = dto.items.reduce((sum, item) => sum + item.subtotal, 0);
    const tax = subtotal * 0.08;
    const total = subtotal + dto.deliveryFee + tax - (dto.discount ?? 0);

    const order = await this.orderRepo.create({
      customerId,
      restaurantId: dto.restaurantId,
      items: dto.items,
      deliveryFee: dto.deliveryFee,
      discount: dto.discount ?? 0,
      subtotal,
      tax,
      total,
      paymentMethod: dto.paymentMethod,
      deliveryAddress: {
        street: dto.deliveryAddress.street,
        city: dto.deliveryAddress.city,
        state: dto.deliveryAddress.state,
        postalCode: dto.deliveryAddress.postalCode,
        country: dto.deliveryAddress.country,
        ...(dto.deliveryAddress.coordinates
          ? { coordinates: dto.deliveryAddress.coordinates }
          : {}),
      },
      ...(dto.notes !== undefined ? { notes: dto.notes } : {}),
    });

    this.logger.info(`Order created: ${order.id}`);
    await this.cache.del(`orders:customer:${customerId}`);

    return order;
  }

  async getOrderById(orderId: string) {
    const order = await this.orderRepo.findById(orderId);
    if (!order) throw new NotFoundError('Order');
    return order;
  }

  async getCustomerOrders(customerId: string, query: PaginationQuery) {
    const cacheKey = `orders:customer:${customerId}:${query.page}`;
    const cached = await this.cache.get(cacheKey);
    if (cached) return cached;

    const result = await this.orderRepo.findByCustomer(customerId, query);
    await this.cache.set(cacheKey, result, 60);
    return result;
  }

  async getRestaurantOrders(restaurantId: string, query: PaginationQuery) {
    return this.orderRepo.findByRestaurant(restaurantId, query);
  }

  async getPendingOrders(restaurantId: string) {
    return this.orderRepo.findPendingOrders(restaurantId);
  }

  async getActiveRiderOrders(riderId: string) {
    return this.orderRepo.findActiveOrdersForRider(riderId);
  }

  async updateOrderStatus(orderId: string, dto: UpdateOrderStatusDto, actor: JwtAccessPayload) {
    const order = await this.orderRepo.findById(orderId);
    if (!order) throw new NotFoundError('Order');

    const { status, cancelReason, riderId } = dto;
    const previousStatus = order.status;

    if (!ORDER_TRANSITIONS[previousStatus]?.includes(status)) {
      throw new BadRequestError(`Invalid transition: ${previousStatus} -> ${status}`);
    }

    const allowedRoles = TRANSITION_PERMISSIONS[status];
    if (allowedRoles && !allowedRoles.includes(actor.role)) {
      throw new ForbiddenError(`Role '${actor.role}' cannot set status to '${status}'`);
    }

    if (
      status === OrderStatus.CANCELLED &&
      actor.role === UserRole.CUSTOMER &&
      order.customerId !== actor.sub
    ) {
      throw new ForbiddenError('You can only cancel your own orders');
    }

    const updates: Record<string, unknown> = { status };
    if (status === OrderStatus.DELIVERED) updates.deliveredAt = new Date();
    if (status === OrderStatus.CANCELLED) {
      updates.cancelledAt = new Date();
      if (cancelReason) updates.cancelReason = cancelReason;
    }
    if (status === OrderStatus.OUT_FOR_DELIVERY && riderId) {
      updates.riderId = riderId;
    }

    const updated = await this.orderRepo.update(orderId, updates);
    this.logger.info(`Order ${orderId} status: ${previousStatus} -> ${status} by ${actor.sub}`);

    return updated;
  }

  private isValidTransition(from: OrderStatus, to: OrderStatus): boolean {
    return ORDER_TRANSITIONS[from]?.includes(to) ?? false;
  }
}
