import type { SocketGateway } from '@/infrastructure/messaging/socket.gateway';
import { createLogger } from '@/shared/utils/logger';
import type {
  OrderCreatedPayload,
  OrderStatusChangedPayload,
  RiderAssignedPayload,
} from '../events/order.events';
import { ORDER_EVENTS } from '../events/order.events';

const log = createLogger('OrderEventService');

export class OrderEventService {
  constructor(private readonly gateway: SocketGateway) {}

  emitOrderCreated(payload: OrderCreatedPayload): void {
    log.info('Emitting order:created', { orderId: payload.orderId });
    // Notify restaurant room
    this.gateway.emitNewOrder(payload.restaurantId, {
      event: ORDER_EVENTS.CREATED,
      data: payload,
    });
    // Notify the order room (customer listening)
    this.gateway.emitOrderUpdate(payload.orderId, {
      event: ORDER_EVENTS.CREATED,
      data: payload,
    });
  }

  emitStatusChanged(payload: OrderStatusChangedPayload): void {
    log.info('Emitting order:status:changed', {
      orderId: payload.orderId,
      from: payload.previousStatus,
      to: payload.newStatus,
    });
    this.gateway.emitOrderUpdate(payload.orderId, {
      event: ORDER_EVENTS.STATUS_CHANGED,
      data: payload,
    });
    this.gateway.emitNewOrder(payload.restaurantId, {
      event: ORDER_EVENTS.STATUS_CHANGED,
      data: payload,
    });
  }

  emitRiderAssigned(payload: RiderAssignedPayload): void {
    log.info('Emitting order:rider:assigned', {
      orderId: payload.orderId,
      riderId: payload.riderId,
    });
    this.gateway.emitOrderUpdate(payload.orderId, {
      event: ORDER_EVENTS.RIDER_ASSIGNED,
      data: payload,
    });
  }
}
